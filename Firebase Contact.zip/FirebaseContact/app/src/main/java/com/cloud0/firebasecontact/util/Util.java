package com.cloud0.firebasecontact.util;

public class Util {

    public static final String TABLE_NAME = "contacts";
    // column 이름
    public static final String KEY_NAME="name";
    public static final String KEY_PHONE_NUMBER="phone_number";
}
